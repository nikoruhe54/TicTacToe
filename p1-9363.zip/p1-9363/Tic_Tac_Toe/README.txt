Nikolai Ruhe
AI Class
02/18/2018
Dr. Chan

README

To run the tic tac toe game:
open a linux terminal,
extract the p1-9363 folder,
navigate to the TicTacToe directory,
run the following command:

python Play_Game.py

To play the game, when prompted:
enter the difficulty (beginner or expert)
enter the size of the board you want to play (3 or 4)
enter if you (the human) want to move first or second (first or second)

Each space on the board is labeled as a number. The 3x3 board is as follows:

1, 2, 3,
4, 5, 6,
7, 8, 9

The 4x4 board is as follows:
1, 2, 3, 4, 
5, 6, 7, 8, 
9, 10, 11, 12,
13, 14, 15, 16

The computer will move automatically. It will tell you when the game is over
and which player won.