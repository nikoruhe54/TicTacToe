#Niko Ruhe
#AI Class
#University of Akron
#Dr. Chan
#02/18/2018

class Space:

    def __init__(self, state, winMoves):
        self.state = state
        self.winMoves = winMoves
